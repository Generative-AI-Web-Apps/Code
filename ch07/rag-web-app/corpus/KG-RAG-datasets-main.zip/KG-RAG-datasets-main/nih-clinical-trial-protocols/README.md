# NIH Clinical Trial Protocols


> Status: DRAFT (documents only, qna_data in progress)

Downloaded from clinicaltrials.gov using this query: https://clinicaltrials.gov/search

Settings: 
1. Study Documents: Study protocols 
2. First posted after: 2023-11-24 

There is a download button. The downloaded file was saved as `download.csv` and only 20 data rows were kept. Look at the current file for the columns selected for download.

The files were then downloaded using:

`python download.py`